public interface Movement
{
    public String move();
}
