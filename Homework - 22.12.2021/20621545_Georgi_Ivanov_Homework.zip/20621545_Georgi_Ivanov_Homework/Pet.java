public interface Pet
{
}
