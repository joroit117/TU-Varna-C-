public interface Tamely
{
}
