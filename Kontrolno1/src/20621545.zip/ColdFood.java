public interface ColdFood {
}
