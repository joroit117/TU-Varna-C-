import java.util.ArrayList;
import java.util.List;

public class FoodTable
{
    private List<Portion> portions;

    FoodTable(){};

    public void addPortion(Food food, double quantity)
    {

    }

    public double sumOfFood()
    {
        double sum = 0;
        for (var portion : portions) {

            sum += portion.getFood().getPrice();
        }
        return sum;
    }

    public double sumOfQuantity()
    {
        double quantity = 0;
        for (var portion : portions) {

            quantity += portion.getQuantity();
        }
        return quantity;
    }

    public List<Soup> getSoups()
    {
        List<Soup> soups = new ArrayList<>();
        for (var portion : portions) {

            if(portion.getFood() instanceof HotFood) {
                soups.add((Soup) portion.getFood());
            }
        }
        return soups;
    }

    public List<Salad> getSalads()
    {
        List<Salad> salads = new ArrayList<>();
        for (var portion : portions) {

            if(portion.getFood() instanceof HotFood) {
                salads.add((Salad) portion.getFood());
            }
        }
        return salads;
    }

}
