public interface HotFood {
}
