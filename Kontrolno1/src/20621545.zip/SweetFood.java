public interface SweetFood {
}
